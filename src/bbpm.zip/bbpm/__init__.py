"""BBPM: Block-Based Permutation Memory for Long-Context Neural Systems."""

__version__ = "0.1.0"
