"""Pseudo-random permutation (Feistel PRP) implementation.

This module provides a keyed, deterministic permutation over power-of-two
domains using Feistel networks. The implementation uses mix64-based round
functions for strong cryptographic mixing.
"""

from dataclasses import dataclass

from bbpm.addressing.hash_mix import mix64, u64


@dataclass(frozen=True)
class FeistelPRP:
    """Feistel network-based pseudo-random permutation.

    Implements a keyed PRP over domain [0, 2^nbits) using Feistel rounds.
    Domain size must be a power of two (L = 2^nbits).

    Attributes:
        nbits: Number of bits (m), domain size is 2**nbits
        rounds: Number of Feistel rounds (>= 6 recommended for security)
        master_key: Master key (uint64) for round constant generation
    """

    nbits: int  # m, domain size is 2**nbits
    rounds: int  # >= 6 recommended
    master_key: int  # uint64

    def __post_init__(self) -> None:
        """Validate parameters."""
        assert self.nbits > 0, "nbits must be positive"
        assert self.rounds >= 6, "rounds should be >= 6 for security"
        assert 0 <= self.master_key < 2**64, "master_key must be uint64"

    def _split(self, x: int) -> tuple[int, int]:
        """Split x into left and right halves.

        If nbits is odd, right half gets the extra bit.

        Args:
            x: Input value in [0, 2**nbits)

        Returns:
            (left, right) tuple where left has nbits//2 bits,
            right has (nbits+1)//2 bits
        """
        left_bits = self.nbits // 2
        right_bits = (self.nbits + 1) // 2

        right_mask = (1 << right_bits) - 1
        right = x & right_mask
        left = x >> right_bits

        return left, right

    def _combine(self, left: int, right: int) -> int:
        """Combine left and right halves back into full value.

        Args:
            left: Left half (nbits//2 bits)
            right: Right half ((nbits+1)//2 bits)

        Returns:
            Combined value in [0, 2**nbits)
        """
        right_bits = (self.nbits + 1) // 2
        return (left << right_bits) | right

    def _get_round_constant(self, round_idx: int) -> int:
        """Get deterministic round constant for given round.

        Round constants are derived from master_key via repeated mixing.

        Args:
            round_idx: Round index (0-based)

        Returns:
            Round constant (uint64)
        """
        # Start with master_key, mix (round_idx + 1) times
        state = u64(self.master_key)
        for _ in range(round_idx + 1):
            state = mix64(state)
        return state

    def _round_function(self, r: int, round_idx: int, key: int) -> int:
        """Feistel round function F.

        F(r, round_idx, key) = lower_half_bits(mix64(r ^ key ^ round_constant ^ master_key))

        Args:
            r: Right half input
            round_idx: Current round index (0-based)
            key: Per-item key (uint64)

        Returns:
            Round function output (lower half bits)
        """
        # Get round constant (derived deterministically from master_key)
        round_const = self._get_round_constant(round_idx)

        # Combine all inputs: r ^ key ^ round_constant ^ master_key
        combined = u64(r) ^ u64(key) ^ u64(round_const) ^ u64(self.master_key)

        # Apply mixing
        mixed = mix64(combined)

        # Extract lower half bits
        half_bits = (self.nbits + 1) // 2  # Right half size
        return mixed & ((1 << half_bits) - 1)

    def permute(self, x: int, key: int) -> int:
        """Apply PRP permutation.

        Returns PRP_k(x) in [0, 2**nbits). key is per-item seed (uint64).
        Deterministic, bijective for any fixed key.

        Args:
            x: Input value in [0, 2**nbits)
            key: Per-item key (uint64)

        Returns:
            Permuted value in [0, 2**nbits)

        Example:
            >>> prp = FeistelPRP(nbits=8, rounds=6, master_key=42)
            >>> y = prp.permute(100, key=123)
            >>> x_recovered = prp.invert(y, key=123)
            >>> x_recovered == 100
            True
        """
        # Validate inputs
        assert 0 <= x < (1 << self.nbits), f"x must be in [0, 2**{self.nbits})"
        assert 0 <= key < 2**64, "key must be uint64"

        # Mask x to domain
        domain_mask = (1 << self.nbits) - 1
        x = x & domain_mask

        # Split into halves
        left, right = self._split(x)

        # Apply Feistel rounds
        for round_idx in range(self.rounds):
            # F(right, round_idx, key)
            f_out = self._round_function(right, round_idx, key)

            # XOR with left
            new_right = left ^ f_out

            # Swap for next round (left becomes right, right becomes new_right)
            left = right
            right = new_right

            # Mask to half sizes
            left_bits = self.nbits // 2
            right_bits = (self.nbits + 1) // 2
            left = left & ((1 << left_bits) - 1)
            right = right & ((1 << right_bits) - 1)

        # Final swap (after all rounds)
        left, right = right, left

        # Combine and mask to domain
        result = self._combine(left, right)
        return result & domain_mask

    def invert(self, y: int, key: int) -> int:
        """Inverse permutation for validation/tests.

        Exactly reverses permute(). For any x, key:
            invert(permute(x, key), key) == x

        Args:
            y: Permuted value in [0, 2**nbits)
            key: Per-item key (uint64)

        Returns:
            Original value in [0, 2**nbits)

        Example:
            >>> prp = FeistelPRP(nbits=8, rounds=6, master_key=42)
            >>> y = prp.permute(100, key=123)
            >>> prp.invert(y, key=123)
            100
        """
        # Validate inputs
        assert 0 <= y < (1 << self.nbits), f"y must be in [0, 2**{self.nbits})"
        assert 0 <= key < 2**64, "key must be uint64"

        # Mask y to domain
        domain_mask = (1 << self.nbits) - 1
        y = y & domain_mask

        # Split into halves
        left, right = self._split(y)

        # Reverse the final swap from permute()
        left, right = right, left

        # Apply Feistel rounds in reverse order
        for round_idx in range(self.rounds - 1, -1, -1):
            # Standard Feistel inverse: L_i = R_{i+1} ^ F(L_{i+1}), R_i = L_{i+1}
            # We have L_{i+1} = left, R_{i+1} = right
            # Need to compute: L_i = right ^ F(left), R_i = left
            f_out = self._round_function(left, round_idx, key)
            new_left = right ^ f_out
            new_right = left

            # Update for next iteration
            left = new_left
            right = new_right

            # Mask to half sizes
            left_bits = self.nbits // 2
            right_bits = (self.nbits + 1) // 2
            left = left & ((1 << left_bits) - 1)
            right = right & ((1 << right_bits) - 1)

        # Combine and mask to domain
        result = self._combine(left, right)
        return result & domain_mask
