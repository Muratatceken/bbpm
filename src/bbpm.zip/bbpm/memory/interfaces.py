"""Abstract interfaces for memory operations.

This module defines the canonical interface for BBPM memory implementations.
Experiments should import IBbpmMemory and MemoryConfig from this module to
ensure compatibility across different memory implementations.
"""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import torch


@dataclass(frozen=True)
class MemoryConfig:
    """Configuration for BBPM memory.

    Attributes:
        num_blocks: Number of blocks (B)
        block_size: Size of each block (L), must be power of 2
        key_dim: Payload dimension (d)
        K: Number of slots per item
        H: Number of independent hash families
        dtype: Data type ("float32" or "bfloat16")
        device: Device ("cpu" or "cuda")
        normalize_values: Normalization mode ("none" | "l2" | "rms")
        read_mode: Read mode ("raw_mean" | "count_normalized")
        master_seed: Master seed (uint64)
    """

    num_blocks: int
    block_size: int
    key_dim: int  # d (payload dimension)
    K: int
    H: int
    dtype: str  # "float32" or "bfloat16"
    device: str  # "cpu" or "cuda"
    normalize_values: str  # "none" | "l2" | "rms"
    read_mode: str  # "raw_mean" | "count_normalized"
    master_seed: int

    def __post_init__(self) -> None:
        """Validate parameters."""
        assert self.num_blocks > 0, "num_blocks must be positive"
        assert self.block_size > 0, "block_size must be positive"
        assert (
            self.block_size & (self.block_size - 1) == 0
        ), f"block_size must be power of 2, got {self.block_size}"
        assert self.key_dim > 0, "key_dim must be positive"
        assert self.K > 0, "K must be positive"
        assert self.H > 0, "H must be positive"
        assert self.dtype in (
            "float32",
            "bfloat16",
        ), f"dtype must be 'float32' or 'bfloat16', got {self.dtype}"
        assert self.device in (
            "cpu",
            "cuda",
        ), f"device must be 'cpu' or 'cuda', got {self.device}"
        assert self.normalize_values in (
            "none",
            "l2",
            "rms",
        ), f"normalize_values must be 'none', 'l2', or 'rms', got {self.normalize_values}"
        assert self.read_mode in (
            "raw_mean",
            "count_normalized",
        ), f"read_mode must be 'raw_mean' or 'count_normalized', got {self.read_mode}"
        assert 0 <= self.master_seed < 2**64, "master_seed must be uint64"


class IBbpmMemory(Protocol):
    """Protocol for BBPM memory implementations.

    This protocol defines the canonical interface that all BBPM memory
    implementations must follow. Experiments should import and use this
    interface to ensure compatibility.

    Any class implementing this protocol must provide:
    - A `cfg` attribute of type MemoryConfig
    - `reset()` method to clear memory
    - `write(hx, v)` method to write values
    - `read(hx)` method to read values
    - `stats()` method to get statistics
    """

    cfg: MemoryConfig

    def reset(self) -> None:
        """Reset memory to initial state (clear all contents)."""
        ...

    def write(self, hx: int, v: "torch.Tensor") -> None:
        """Write value to memory at addresses derived from hashed key.

        Args:
            hx: Hashed item key (uint64)
            v: Value tensor of shape [d] (key_dim)
        """
        ...

    def read(self, hx: int) -> "torch.Tensor":
        """Read value from memory using hashed key.

        Args:
            hx: Hashed item key (uint64)

        Returns:
            Retrieved value tensor of shape [d] (key_dim)
        """
        ...

    def stats(self) -> dict:
        """Get memory statistics.

        Returns:
            Dictionary containing memory statistics (e.g., occupancy,
            collision rates, etc.)
        """
        ...
